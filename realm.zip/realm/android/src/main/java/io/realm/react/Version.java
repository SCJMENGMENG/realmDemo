package io.realm.react;

public class Version {
    public static final String VERSION = "2.19.0";
}
